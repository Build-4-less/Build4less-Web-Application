import React, { useState } from 'react';

function App() {
 const [lightStatus, setLightStatus] = useState('off');
 const toggleLight = () => setLightStatus(lightStatus === 'on' ? 'off' : 'on');
 return (
 <div style={{ textAlign: 'center', marginTop: '50px' }}>
 <h1>Lighting Control</h1>
 <p>Light is currently {lightStatus}</p>
 <button onClick={toggleLight}>Toggle Light</button>
 </div>
 );
}
export default App;